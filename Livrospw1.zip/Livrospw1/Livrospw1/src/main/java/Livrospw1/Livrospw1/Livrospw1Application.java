package Livrospw1.Livrospw1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Livrospw1Application {

	public static void main(String[] args) {
		SpringApplication.run(Livrospw1Application.class, args);
	}

}
