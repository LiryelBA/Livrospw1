package Livrospw1.Livrospw1.service;

import Livrospw1.Livrospw1.model.Livros;
import Livrospw1.Livrospw1.repository.LivrosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LivrosService {


    private final LivrosRepository repository;

    public List<Livros> findbyTituloo(String titulo){
      return repository.findByTitulo(titulo);
    }

    public LivrosService(LivrosRepository repository) {
        this.repository = repository;
    }

    public Livros create(Livros f){
        return repository.save(f);
    }

    public void deleteById(Long id){
        repository.deleteById(id);
    }


    public Livros update(Livros f){
        return repository.saveAndFlush(f);
    }

    public Livros findById(Long id){
        Optional<Livros> FilmeOptional = repository.findById(id);
        return FilmeOptional.orElse(null);
    }

    public List<Livros> findAll(){
        return repository.findAll();
    }
}
