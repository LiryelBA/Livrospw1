package Livrospw1.Livrospw1.controlller;

import Livrospw1.Livrospw1.model.Livros;
import Livrospw1.Livrospw1.repository.LivrosRepository;
import Livrospw1.Livrospw1.service.LivrosService;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.StringTokenizer;

@Controller
public class LivrosController {

    private final LivrosService service;

    public LivrosController(LivrosService service) {
        this.service = service;
    }

    @GetMapping("/admin")
    public String getLivrosHome(Model model){
        List<Livros> livros = service.findAll();
        model.addAttribute("livros", livros);
        return "index";
    }

    @GetMapping("/user")
    public String getHome(Model model){
        List<Livros> livros = service.findAll();
        model.addAttribute("livros", livros);
        return "indexUser";
    }

    @GetMapping("/cadastrar")
    public String getLivrosCadastro(Model model){
        Livros l = new Livros();
        model.addAttribute("livros", l);
        return "cadastrar";
    }
    @GetMapping("editar/{id}")
    public String getLivrosHome(Model model, @PathVariable Long id){
        Livros livros = service.findById(id);
        model.addAttribute("livros", livros);
        return "cadastrar";
    }

    @GetMapping("deletar/{id}")
    public String doDeletarLivros(@PathVariable Long id){
        service.deleteById(id);
        return "redirect:/admin";
    }

    @PostMapping("salvar")
    public String doSalvaLivros(@ModelAttribute Livros l){
        service.update(l);
        return "redirect:/admin";
    }

    @GetMapping("/buscar")
    public String getTituloBuscar(Model model,@RequestParam(name="nomepesquisa") String nomepesquisa){
        List<Livros> livros = service.findbyTituloo(nomepesquisa);
        model.addAttribute("livros", livros);
        return "index";
    }




}
